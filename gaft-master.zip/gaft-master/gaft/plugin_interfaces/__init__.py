from ..plugin_interfaces.operators import *
from ..plugin_interfaces.analysis import OnTheFlyAnalysis

