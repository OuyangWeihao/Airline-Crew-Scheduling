from .selection import Selection
from .crossover import Crossover
from .mutation import Mutation

